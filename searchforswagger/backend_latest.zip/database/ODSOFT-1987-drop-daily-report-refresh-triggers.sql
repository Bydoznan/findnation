DROP TRIGGER IF EXISTS tg_refresh_mv_report ON public.resource;
DROP TRIGGER IF EXISTS tg_refresh_mv_report ON public.dataset;
DROP TRIGGER IF EXISTS tg_refresh_mv_report ON public.organization;
DROP TRIGGER IF EXISTS tg_refresh_mv_report ON public.user;
DROP TRIGGER IF EXISTS tg_refresh_mv_report ON public.user_following_dataset;
