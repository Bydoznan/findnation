# Changelog

> sekcja do skopiowania do CHANGELOG.md przy release

### New

- Opis zmiany - OTD-NNN

### Changes

### Fixes

### Breaks

# Komentarz

> Tu napisz komentarz dla zespołu deweloperskiego, np. jeśli są wymagane akcje na lokalnym środowisku
