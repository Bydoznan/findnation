from mcod.core.tests.fixtures import *  # noqa
