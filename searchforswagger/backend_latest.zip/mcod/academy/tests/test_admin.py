from pytest_bdd import scenarios

scenarios("features/course_details_admin.feature", "features/courses_list_admin.feature")
