from pytest_bdd import scenarios

scenarios("features/courses_list_api.feature")
