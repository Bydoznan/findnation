from mcod.core.signals import ExtendedSignal

update_related_datasets = ExtendedSignal()
null_in_related_datasets = ExtendedSignal()
