class ElasticsearchIndexError(Exception):
    """Raised when there is an issue accessing or querying an Elasticsearch index."""
