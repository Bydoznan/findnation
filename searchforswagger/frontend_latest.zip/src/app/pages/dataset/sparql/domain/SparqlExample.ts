export interface SparqlExample {
  displayName: { [key: string]: string };
  codeSnippet: string;
}
