export interface Alert {
    type: string;
    msg: string;
}
