export interface StartEndDateRange {
    startDate: Date;
    endDate: Date;
}
