export enum IRawTextEmbedType {
    IMAGE = 'image',
    MEDIA = 'media',
    DOCUMENT = 'document'
}
