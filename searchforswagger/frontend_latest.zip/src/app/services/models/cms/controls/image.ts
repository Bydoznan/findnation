export interface IImage {
    image: {
        download_url: string,
        height: number,
        title: string,
        width: number
    };
    position: string;
}
