export interface ISpace {
    unit: string;
    left: number;
    top: number;
    right: number;
    bottom: number;
}
