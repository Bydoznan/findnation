export interface IColor {
    r: number;
    g: number;
    b: number;
    a: number;
}
