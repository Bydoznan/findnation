export interface IBackgroundImage {
    color: string;
    image: {[key: string]: string};
    paralax: boolean;
}
