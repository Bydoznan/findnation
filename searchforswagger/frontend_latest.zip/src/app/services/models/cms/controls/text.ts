export interface IText {
    text: string;
    align: string;
}
