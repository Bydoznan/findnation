export enum IRawTextObjectType {
    STRING, EMBED
}
