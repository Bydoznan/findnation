export interface IButton {
    action_url: string;
    position: string;
    size: string;
    style: string;
    target: string;
    text: string;
}
