import {IWidget} from '@app/services/models/cms/widgets/widget';

export interface IRawText extends IWidget {
    value: string;
}
