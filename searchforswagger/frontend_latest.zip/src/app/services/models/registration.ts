export interface IRegistration {
    email: string;
    password1: string;
    password2: string;
    subscriptions_report_opt_in: boolean;
    rodo_privacy_policy_opt_in: boolean;
}
