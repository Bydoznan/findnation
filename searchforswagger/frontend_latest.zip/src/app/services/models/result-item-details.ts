export interface ResultItemDetailsData {
  titleTranslationKey: string;
  data: string;
  isDate?: boolean;
  dateFormat?: string;
  language?: string;
}
