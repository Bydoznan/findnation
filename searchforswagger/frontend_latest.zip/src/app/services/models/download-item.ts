export interface IDownloadFile {
    title?: string;
    url: string;
}
