export enum StrategiesEnum {
  defaultStrategy = 'default',
  envName = 'environmentName',
  hostName = 'applicationHostname',
}
