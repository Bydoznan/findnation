export enum ApiParametersConfig {
  FACET_WITH_TERMS = 'facet[terms]',
}
