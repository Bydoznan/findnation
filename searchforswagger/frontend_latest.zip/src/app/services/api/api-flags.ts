export enum ApiFlagsConfig {
  registerClient = '/flags/api/client/register',
  flags = '/flags/api/client/features',
}
