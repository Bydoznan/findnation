export interface BreadcrumbConfig {
    label?: string;
    translationKey?: string;
    dataKey?: string;
}
