export enum Feedback {
    PLUS = 'plus',
    MINUS = 'minus'
}
